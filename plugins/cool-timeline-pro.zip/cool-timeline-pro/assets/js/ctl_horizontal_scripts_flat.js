jQuery("document").ready(function($) {

    function storySlideShow(container){
        container.find(".ctl_slideshow .slides").not('.slick-initialized').each(function(){
        var autoplaySpeed=parseInt($(this).data('animationspeed'));
        var slideshow=$(this).data('slideshow');
        $(this).slick({
            dots: false,
            infinite: false,
            arrows:true,
            mobileFirst:true,
            pauseOnHover:true,
            slidesToShow:1,
            autoplay:slideshow,
            autoplaySpeed:autoplaySpeed,
             adaptiveHeight: true
          });      
        }); 
    }

    $(".cool-timeline-horizontal.ht-design-2").each(function(o) {
            var thisS =$(this);
            var sliderContent= "#" + thisS.attr("date-slider"),
                sliderNav = "#" + thisS.attr("data-nav"),
                rtl = thisS.attr("data-rtl"),
                items= parseInt(thisS.attr("data-items")),
                autoplay = thisS.attr("data-autoplay"),
                autoplaySettings=autoplay=="true"?true:false,
                rtlSettings=rtl=="true"?true:false,
                startOn= parseInt(thisS.attr("data-start-on")),
                lineFilling=thisS.attr("data-line-filling"),
                speed = parseInt(thisS.attr("data-autoplay-speed"));
                
            thisS.siblings(".clt_preloader").hide();
            thisS.css("opacity",1);
            
            let totalslide=$(sliderContent+' li[data-term-slug]').length;
            let lastshow_items=(totalslide - startOn);
 
            if(lastshow_items < items){
             startOn=totalslide-items;
            }

         $(sliderNav).not('.slick-initialized').slick( {
                slidesToShow: items,
                slidesToScroll: 1, 
                autoplaySpeed:speed, 
                asNavFor:sliderContent,
                dots:false, 
                autoplay:autoplaySettings, 
                rtl:rtlSettings, 
                initialSlide:startOn, 
                focusOnSelect:true, 
                infinite:false, 
                nextArrow: '<button type="button" class="ctl-slick-next "><i class="far fa-arrow-alt-circle-right"></i></button>', 
                prevArrow: '<button type="button" class="ctl-slick-prev"><i class="far fa-arrow-alt-circle-left"></i></button>',
                responsive: [ {
                breakpoint: 980, 
                    settings: {
                        slidesToShow: 2, 
                        slidesToScroll: 1,
                        centerPadding: "10px"
                    }
                }
                , {
                    breakpoint: 768, 
                    settings: {
                         arrows:true,
                         centerPadding: "10px", 
                         slidesToShow: 1
                    }
                }
                , {
                    breakpoint: 480,
                     settings: {
                        arrows:true,
                        centerPadding: "10px", 
                        slidesToShow: 1
                    }
                }
                ]
            }
            
            ),
            $(sliderContent).not('.slick-initialized').slick( {
                slidesToShow:items,
                slidesToScroll: 1, 
                asNavFor:sliderNav, 
                arrows:false, 
                dots:false,
                rtl:rtlSettings, 
                initialSlide:startOn,
                infinite:false, 
                adaptiveHeight:true,
                responsive: [ {
                 breakpoint: 980, 
                    settings: {
                        slidesToShow: 2, 
                        slidesToScroll: 1,
                        centerPadding: "10px"
                    }
                }
                , {
                breakpoint: 768, 
                    settings: {
                        slidesToShow: 1, 
                        slidesToScroll: 1,
                        centerPadding: "10px"
                     }
                    }
                , {
                breakpoint: 480,
                 settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    centerPadding: "10px"
                 }
                 }
                ]
                }

                );

            //enable story slideshow
            storySlideShow(thisS);

        });
});