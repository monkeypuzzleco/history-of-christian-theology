// Include stylesheet
import './style.scss';

import './story-tm-block.js';
import './content-tm-block.js';
